package Model;

public enum Level {
	Pharm,Manager,Admin;
}
